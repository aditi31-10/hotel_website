<?=template_header('Place Order')?>

<div class="placeorder content-wrapper">
    <center>
    <h1>Payment</h1>

    <button onclick="fuc()">Cash on Delivery</button>
   <p id="cod"></p>
    <br><br>
    <button onclick="window.open('https://pay.google.com','_blank')">Online Payment</button>
    <br><br>
</div>
<script>
    function fuc()
    {
    document.getElementById("cod").innerHTML="Your Order Has Been Placed.Thank you for ordering with us, we'll contact you by email with your order details."
    }

</script>
